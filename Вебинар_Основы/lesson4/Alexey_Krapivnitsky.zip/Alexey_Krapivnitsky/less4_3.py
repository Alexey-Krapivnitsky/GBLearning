print(*[el for el in range(20, 241) if not el % 20 or not el % 21])
