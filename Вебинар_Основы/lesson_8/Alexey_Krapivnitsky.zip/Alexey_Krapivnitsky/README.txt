29.02.2020 12:58 start
29.02.2020 17:05 задачи 1 - 3
01.03.2020 19:30 start
02.03.2020 01:54 задачи 4-7

Пример для умножения комплексных чисел из https://studopedia.ru/9_86178_kompleksnie-chisla-i-deystviya-nad-nimi.html